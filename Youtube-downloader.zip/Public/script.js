// ================ DOM Elements ================
const mobileMenuBtn = document.getElementById('mobileMenuBtn');
const navLinks = document.getElementById('navLinks');
const downloadForm = document.getElementById('downloadForm');
const urlInput = document.querySelector('.url-input');
const formatSelect = document.getElementById('formatSelect');
const downloadBtn = document.getElementById('downloadBtn');
const spinner = document.getElementById('spinner');

// ================ Constants ================
const BACKEND_URL = window.location.origin.includes('localhost') 
    ? 'http://localhost:3001' 
    : window.location.origin;

// ================ Mobile Menu Toggle ================
mobileMenuBtn.addEventListener('click', () => {
    navLinks.classList.toggle('active');
    mobileMenuBtn.innerHTML = navLinks.classList.contains('active') 
        ? '<i class="fas fa-times"></i>' 
        : '<i class="fas fa-bars"></i>';
});

// ================ Smooth Scrolling ================
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        
        if (navLinks.classList.contains('active')) {
            navLinks.classList.remove('active');
            mobileMenuBtn.innerHTML = '<i class="fas fa-bars"></i>';
        }
        
        const targetId = this.getAttribute('href');
        if (targetId === '#') return;
        
        const targetElement = document.querySelector(targetId);
        if (targetElement) {
            window.scrollTo({
                top: targetElement.offsetTop - 80,
                behavior: 'smooth'
            });
        }
    });
});

// ================ Download Functionality ================
// Create status message element
const statusMessage = document.createElement('div');
statusMessage.id = 'statusMessage';
statusMessage.className = 'status-message';
downloadForm.appendChild(statusMessage);

// Validate YouTube URL
const isValidYouTubeUrl = (url) => {
    const pattern = /^(https?:\/\/)?(www\.)?(youtube\.com|youtu\.be)\/.+/;
    return pattern.test(url);
};

// Show status message
const showStatus = (message, type = 'info') => {
    statusMessage.innerHTML = '';
    statusMessage.className = `status-message ${type}`;
    
    if (type === 'success' && typeof message === 'object') {
        statusMessage.innerHTML = `
            <div class="download-preview">
                <img src="${message.thumbnail}" alt="Video thumbnail">
                <div class="preview-info">
                    <h4>${message.title}</h4>
                    <p>Format: ${message.format}</p>
                </div>
            </div>
            <p class="download-hint">If download doesn't start automatically, check your pop-up blocker.</p>
        `;
    } else {
        statusMessage.textContent = message;
    }
    
    statusMessage.style.display = 'block';
    
    if (type !== 'success') {
        setTimeout(() => {
            statusMessage.style.display = 'none';
        }, 5000);
    }
};

// Handle download form submission
downloadForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const youtubeUrl = urlInput.value.trim();
    const format = formatSelect.value;

    // Validate input
    if (!youtubeUrl) {
        showStatus('Please enter a YouTube URL', 'error');
        urlInput.focus();
        return;
    }

    if (!isValidYouTubeUrl(youtubeUrl)) {
        showStatus('Please enter a valid YouTube URL', 'error');
        urlInput.focus();
        return;
    }

    // UI Feedback
    downloadBtn.disabled = true;
    spinner.style.display = 'block';
    showStatus('Processing your request...', 'info');

    try {
        // First get video info
        const infoResponse = await fetch(`${BACKEND_URL}/api/info`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url: youtubeUrl })
        });

        if (!infoResponse.ok) {
            const errorData = await infoResponse.json();
            throw new Error(errorData.error || 'Failed to get video info');
        }

        const videoInfo = await infoResponse.json();
        
        // Show video info to user
        showStatus({
            title: videoInfo.title,
            thumbnail: videoInfo.thumbnail,
            format: formatSelect.options[formatSelect.selectedIndex].text
        }, 'success');

        // Start download
        const downloadResponse = await fetch(`${BACKEND_URL}/api/download`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                url: youtubeUrl, 
                format: format 
            })
        });

        if (!downloadResponse.ok) {
            const errorData = await downloadResponse.json();
            throw new Error(errorData.error || 'Download failed');
        }

        // Create blob and download
        const blob = await downloadResponse.blob();
        const downloadUrl = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = downloadUrl;
        a.download = `${videoInfo.title.replace(/[^a-z0-9]/gi, '_')}.${format.includes('mp3') ? 'mp3' : 'mp4'}`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(downloadUrl);

    } catch (error) {
        console.error('Download error:', error);
        showStatus(`Download failed: ${error.message}`, 'error');
    } finally {
        downloadBtn.disabled = false;
        spinner.style.display = 'none';
    }
});

// ================ Scroll Animations ================
const fadeElements = document.querySelectorAll('.fade-in');
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('visible');
        }
    });
}, { threshold: 0.1 });

fadeElements.forEach(element => {
    observer.observe(element);
});

// ================ Header Scroll Effect ================
window.addEventListener('scroll', () => {
    const header = document.querySelector('header');
    header.style.boxShadow = window.scrollY > 50 
        ? '0 4px 20px rgba(0,0,0,0.3)' 
        : 'none';
});